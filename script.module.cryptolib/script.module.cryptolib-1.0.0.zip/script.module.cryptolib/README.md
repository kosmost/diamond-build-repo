script.module.cryptolib
===============================

Kodi module that provides the cryptographic functions.

This is based on the two pure Python cryptographic libraries:
 * [CryptoPy](https://pypi.python.org/pypi/cryptopy)
 * [rsa](https://pypi.python.org/pypi/rsa)
 * Michael Gilfix's Blowfish implementation
 