"""
 Author: Tvaddons

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 
 """

import urllib,urllib2,re,xbmcplugin,xbmcgui,os,sys,datetime
from resources.lib.common_variables import *
from resources.lib.directory import *
from resources.lib.youtubewrapper import *
from resources.lib.watched import * 

fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.DiamondCinema', 'fanart.jpg'))
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.DiamondCinema/resources/img', ''))

def CATEGORIES():
        addDir('[COLOR blue]Diamond Cinema[/COLOR]','url',10,'https://i.ytimg.com/vi/qggr2KMogiU/hqdefault.jpg')
        addDir('[COLOR blue]Star Wars and Star Terk The Fan Films[/COLOR]','url',11,'http://images.rubyjewelwizard.com/diamondbuild/imageload/versus.jpg')
        addDir('[COLOR blue]Kings Of Horror[/COLOR]','url',12,'https://i.ytimg.com/vi/lAiRcoDMJVM/hqdefault.jpg')
        addDir('[COLOR blue]Cirque Du Soleil[/COLOR]','url',13,'https://i.ytimg.com/vi/5mNdueJFeG4/hqdefault.jpg')
        addDir('[COLOR blue]Gone Wild[/COLOR]','url',14,'http://images.rubyjewelwizard.com/diamondbuild/imageload/I@045360_L.jpg')
        addDir('[COLOR blue]World Of SAMBA CARNIVAL & DANCE[/COLOR] - [COLOR goldenrod]Some Nudity[/COLOR]','url',15,'https://i.ytimg.com/vi/RmeL7moDY4s/hqdefault.jpg')
        addDir('[COLOR blue]Amazing Wing Suiting![/COLOR]','url',16,'https://i.ytimg.com/vi/pWNlg0QS7XM/hqdefault.jpg')
        addDir('[COLOR blue]Top In Music[/COLOR]','url',17,'https://i.ytimg.com/vi/9vjTCyO2K7k/hqdefault.jpg')
        addDir('[COLOR blue]Body Paint And Dance[/COLOR] - [COLOR goldenrod]Some Nudity[/COLOR]','url',18,'https://i.ytimg.com/vi/kftrSTgAx70/hqdefault.jpg')
        addDir('[COLOR blue]Celebrity News/ Gossip[/COLOR]','url',19,'https://i.ytimg.com/vi/68_DelJ2MUo/hqdefault.jpg')
        addDir('[COLOR blue]Amazing Dancing Dolls[/COLOR]','url',20,'https://i.ytimg.com/vi/jJ6Bumip4HM/hqdefault.jpg')
        addDir('[COLOR blue]Ultimate Music Collection[/COLOR]','url',21,'https://i.ytimg.com/vi/OPo6T7lreqw/hqdefault.jpg')

        logo = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.DiamondCinema','logo.png'))

def DiamondCinema():
        addDir('[COLOR aqua]Full Drama Movies[/COLOR]','PLfRCZ3PuccvBqBum4D3g0FTNOr7Z4vzP2',1,'https://i.ytimg.com/vi/GoJMTYvqMuU/hqdefault.jpg')
        addDir('[COLOR aqua]Full Horror Movies[/COLOR]','PLfRCZ3PuccvB3T6Mv9ZEFzSo0Ge9EBp0c',1,'https://i.ytimg.com/vi/xts9BnhqtWo/hqdefault.jpg')
        addDir('[COLOR aqua]Blaxploitation Films 1[/COLOR]','PLqZdaedwfP_hUEuvsN0fssh1zJpirpXpz',1,'https://i.ytimg.com/vi/qggr2KMogiU/hqdefault.jpg')
        addDir('[COLOR aqua]Blaxploitation Films 2[/COLOR]','PL-KqxyRbNyKAy87-QnE06CMnW8i5gU_Ms',1,'https://i.ytimg.com/vi/bCJ_INhdW9M/hqdefault.jpg')
        addDir('[COLOR aqua]Best of Nigerian Nollywood Mercy Johnson Movies[/COLOR]','PLdNg1nXKWYxlxidFJpJYuy5kEgPK5yPaK',1,'https://i.ytimg.com/vi/oH191Zy26YQ/hqdefault.jpg')
        addDir('[COLOR aqua]Pre-Code Films - (1929-1934)[/COLOR]','PLwALQdqjNQHPgGZ5xShmhd1GfTsvjdP5c',1,'https://i.ytimg.com/vi/sAWouAAEMGA/hqdefault.jpg')
        addDir('[COLOR aqua]1,475 - Kung Fu Films[/COLOR]','PLSvPwyvZG6xZXHU1NtfyLUKiqgtzf8i84',1,'https://i.ytimg.com/vi/YWLxBiLbwTA/hqdefault.jpg')
        addDir('[COLOR aqua]Old School Saturday Afternoon Kung-Fu Flicks[/COLOR]','PLqS70PCC_SYr04hZEu_O2fYBU-Bl5fvZp',1,'https://i.ytimg.com/vi/Uklh-I4Lihc/hqdefault.jpg')
        addDir('[COLOR aqua]Cynthia Rothrock & Martial Arts Movies[/COLOR]','PLZ7J5gWcbni7nISfWDZNqRPbWaZ7oMz0W',1,'https://i.ytimg.com/vi/Oh8KnmRvqd0/hqdefault.jpg')
        addDir('[COLOR aqua]Def Comedy Jam - Popular Videos[/COLOR]','PLq7hdysfg2VY44dxNDJIAcM8IT7srFa0T',1,'https://i.ytimg.com/vi/7JkPx0gk6LE/hqdefault.jpg')
        addDir('[COLOR aqua]Laurel & Hardy All Movies HD - Late 20s[/COLOR]','PLiTfjyghfyIfHS6knALIIkuZSS3IwAcSU',1,'https://i.ytimg.com/vi/iSTH1Ko6iw0/hqdefault.jpg')
        addDir('[COLOR aqua]Benny Hill[/COLOR]','PLFsbvbIo45kfYysHDmgqz9ySlFdFzm7Eq',1,'https://i.ytimg.com/vi/DU1hvWwd5NA/hqdefault.jpg')
        addDir('[COLOR aqua]Rowan Atkinson[/COLOR]','PL152bjytsMC557kLyghLs2xYzdMcglPS_',1,'https://i.ytimg.com/i/E9c2Y2_o7z3bmXw8nUfyTA/mq1.jpg')
        addDir('[COLOR aqua]Monty Python[/COLOR]','PL5D9B54A2765DE20A',1,'https://i.ytimg.com/vi/4vuW6tQ0218/hqdefault.jpg')
        addDir('[COLOR aqua]Shirley Temple RARE FOOTAGE On Set Filming Heidi 1937[/COLOR]','PLoGeCeQU-L91U4juM8C5QygkZKda8h12e',1,'https://i.ytimg.com/vi/S1doC7X_VSM/hqdefault.jpg')

def starfanfilms():
        addDir('[COLOR aqua]Star Wars Fan Films[/COLOR]','PLoGeCeQU-L91hZgcnMIXE0zY6JFn0V7zS',1,'https://i.ytimg.com/vi/NoiI4bWwxoA/hqdefault.jpg')
        addDir('[COLOR aqua]Star Terk Fan Films[/COLOR]','PLoGeCeQU-L91hHxLyAfvl4M_5awoJLgQA',1,'https://i.ytimg.com/vi/rFjKV9IcGV8/hqdefault.jpg')

def KingsOfHorror():
        addDir('[COLOR aqua]Horror Movie Trailers[/COLOR]','PLO6BFV6fgGwtHaaTo_pS8xukPYA-m5ipy',1,'http://i1.ytimg.com/vi/zs3pJTvIEZ8/hqdefault.jpg')
        addDir('[COLOR aqua]Editors Horror Choice[/COLOR]','PLO6BFV6fgGwvuR_oqYudc_CoKAJTjUSjn',1,'https://i.ytimg.com/vi/Pb3ut0aC1_E/hqdefault.jpg')
        addDir('[COLOR aqua]Monster Horrors[/COLOR]','PLO6BFV6fgGwtdn2Cit6wNTFjr4smKUfFp',1,'https://i.ytimg.com/vi/lAiRcoDMJVM/hqdefault.jpg')
        addDir('[COLOR aqua]Editors Horror Choice[/COLOR]','PLO6BFV6fgGwvuR_oqYudc_CoKAJTjUSjn',1,'https://i.ytimg.com/vi/As8FbK8I3IY/hqdefault.jpg')
        addDir('[COLOR aqua]On the Edge of Your Seat Horror[/COLOR]','PLO6BFV6fgGwvIjH7pG3Do9Bgd3E4xHMpP',1,'https://i.ytimg.com/vi/cDll_Mqo10A/hqdefault.jpg')
        addDir('[COLOR aqua]Serial Killer Horrors[/COLOR]','PLO6BFV6fgGwsed2wmznVdmd9MZ-yJqj_4',1,'https://i.ytimg.com/vi/8bZvNfQHTOs/hqdefault.jpg')
        addDir('[COLOR aqua]Psychological Horror[/COLOR]','PLO6BFV6fgGwt5yBHF-H-lODLRc0a_MLEf',1,'http://i.ytimg.com/vi/xOG1EYbp90k/hqdefault.jpg')
        addDir('[COLOR aqua]Demonic Possessions[/COLOR]','PLO6BFV6fgGwshi6dyglSREMxzpCsbI00W',1,'http://i.ytimg.com/vi/G9S9cPqJhD8/hqdefault.jpg')
        addDir('[COLOR aqua]Psychotic Killing Machines[/COLOR]','PLO6BFV6fgGwsed2wmznVdmd9MZ-yJqj_4',1,'https://i.ytimg.com/vi/HpaUXMaWtW4/hqdefault.jpg')
        addDir('[COLOR aqua]Zombie Time[/COLOR]','PLO6BFV6fgGwt5x5KOWp0dBF-2moeUAfXT',1,'http://i.ytimg.com/vi/BuQbSSiss-E/hqdefault.jpg')
        addDir('[COLOR aqua]Fight to Survive[/COLOR]','PLO6BFV6fgGwsl1JbOyGBYvotKdma1Su0C',1,'http://i.ytimg.com/vi/XqTf9pLewzI/hqdefault.jpg')

def cirquedusoleil():
        addDir('[COLOR aqua]Cirque Du Soleil[/COLOR]','RDEMP3dHAEi0ZvUl0krV3THZNw',1,'https://i.ytimg.com/vi/5mNdueJFeG4/hqdefault.jpg')

def urbangonewild():
        addDir('[COLOR aqua]NEW - Urban Gone Wide[/COLOR]','PLoGeCeQU-L92SMeqq_k66yqQ1gyzspJhf',1,'https://i.ytimg.com/vi/0UBTujjjBqM/hqdefault.jpg')
        addDir('[COLOR aqua]Mix - Urban Gone Wide[/COLOR]','PLoGeCeQU-L90vf7UfOpsu08bo0zArfZHj',1,'https://i.ytimg.com/vi/YJkUv-ZZXro/hqdefault.jpg')
        addDir('[COLOR aqua]Mix - Crackheads Gone Wild In The City[/COLOR]','PLoGeCeQU-L912SjmPxVqrgKCLnov2Z9ZD',1,'https://i.ytimg.com/vi/lB8GiWIq-mM/hqdefault.jpg')
        addDir('[COLOR aqua]Mix - Dream Weekend -Wet N- Wild" 2017 [FULL HD][/COLOR]','RDNRzzv3d4wU4',1,'https://i.ytimg.com/vi/PT-lxoVCQ6w/hqdefault.jpg')
        addDir('[COLOR aqua]Mix - BOOK FI LOOK BIRTHDAY BASH 2017[/COLOR]','RD6UL52Z86jJM',1,'https://i.ytimg.com/vi/SqChmINt-uM/hqdefault.jpg')
        addDir('[COLOR aqua]Mix - Trinidad Carnival Tuesday 2016 (filmed by jonfromqueens)[/COLOR]','RDYyhP3nqGqyU',1,'https://i.ytimg.com/vi/94mF9PNGx-8/hqdefault.jpg')

def blameitonrio():
        addDir('[COLOR blue]Blame It on Rio[/COLOR] - [COLOR goldenrod]Some Nudity[/COLOR]','PLoGeCeQU-L90rBHMDPkA-OUgmP4XVdCK7',1,'https://i.ytimg.com/vi/RmeL7moDY4s/hqdefault.jpg')

def nowthatisamazing():
        addDir('[COLOR aqua]** EXTREME WING SUITING EDITION **[/COLOR]','PLoGeCeQU-L91QM1EO4UsxISs9X99QrWW6',1,'https://i.ytimg.com/vi/hOsnVSIIMnE/hqdefault.jpg')

def topinmusic():
        addDir('[COLOR aqua]R&B[/COLOR]','PLAKw47hquUsIWArq-QR2v_wR-JZIjASWv',1,'https://i.ytimg.com/vi/0habxsuXW4g/hqdefault.jpg')
        addDir('[COLOR aqua]Hip Hop[/COLOR]','PLAKw47hquUsLe6xcBQjOLBf69HFyPwhCZ',1,'https://i.ytimg.com/vi/9vjTCyO2K7k/hqdefault.jpg')
        addDir('[COLOR aqua]Sex Tunes (Freaky R&B, Rap) [/COLOR]','PLA3D4CE0630E72D50',1,'https://i.ytimg.com/vi/E98IYokujSY/hqdefault.jpg')
        addDir('[COLOR aqua]Mix - MARIAH CAREY - Its Like That - #1 to Infinity 7/18/17[/COLOR]','RDCfLQvgkGMvE',1,'https://i.ytimg.com/vi/Fw_mWEv-Zdc/hqdefault.jpg')
        addDir('[COLOR aqua]DEVO - Mix[/COLOR]','RDOYQC-DeOcgA',1,'https://i.ytimg.com/vi/aAcOuOaFwyY/hqdefault.jpg')
        addDir('[COLOR aqua]Lindsey Stirling - Mix[/COLOR]','RDEMzT1XwmFnIup_KYXuc2rUZA',1,'https://i.ytimg.com/vi/1A3i0GATnRI/hqdefault.jpg')
        addDir('[COLOR aqua]2CELLOS - 2 Beautiful CELLOS[/COLOR]','PLoGeCeQU-L930yQ7zQg4Mlq3TEnT-cm_g',1,'https://i.ytimg.com/vi/UdHopftQD3A/hqdefault.jpg')

def bodypaint():
        addDir('[COLOR aqua]Body Paint Instead Of Clothes[/COLOR] - [COLOR goldenrod]Some Nudity[/COLOR]','PLoGeCeQU-L91jTcMYI6stlnbzkYROwLt8',1,'https://i.ytimg.com/vi/kftrSTgAx70/hqdefault.jpg')

def gossip():
        addDir('[COLOR aqua]TMZ - Celebrity News/ Gossip[/COLOR]','PLIPm6JAyEJ_cwC-hnK52H5XASy-cSpYdJ',1,'https://i.ytimg.com/vi/68_DelJ2MUo/hqdefault.jpg')
        addDir('[COLOR aqua]Wendy Williams - Hot Topics[/COLOR]','PLA5A724EA449A7DE4',1,'https://i.ytimg.com/vi/-euDYyoh0to/hqdefault.jpg')
        addDir('[COLOR aqua]Wendy Williams - Celebrity Interviews[/COLOR]','PLY5MHIzEuCPCyhhwlRHZpigfl154u1gL4',1,'https://i.ytimg.com/vi/OQdo1hOJfdg/hqdefault.jpg')

def amazingddolls():
        addDir('[COLOR aqua]Amazing Dancing Dolls[/COLOR]','PLoGeCeQU-L92RFHTpAQvd-TFfeJ2FvvJq',1,'https://i.ytimg.com/vi/jJ6Bumip4HM/hqdefault.jpg')
        addDir('[COLOR aqua]Amazing Baby Dancing Dolls[/COLOR]','PLoGeCeQU-L90pXSjX77bkASvxG2hiNbzn',1,'https://i.ytimg.com/vi/DfptC0tbHQA/hqdefault.jpg')

def rockcollection():
        addDir('[COLOR orchid][B]GREATEST SLOW ROCK SONGS[/B][/COLOR]','PLq0ajtdli5G8idRnNPS_ei1eBimVu8tcn',1,art + 'http://legionworldtv.com/freeworld/images/rock.jpg')
        addDir('[COLOR blue][B]80S SOFT ROCK LOVE SONGS[/B][/COLOR]','PLq0ajtdli5G8idRnNPS_ei1eBimVu8tcn&index=1',1,art + 'http://legionworldtv.com/freeworld/images/rock.jpg')
        addDir('[COLOR yellow][B]ROCK SONGS HITS ALL TIME[/B][/COLOR]','PLp56AzR7YZeulJwWZc4yur7ooDg_UtKhD',1,art + '')
        addDir('[COLOR lime][B]CLASSIC SONGS 80S 90S[/B][/COLOR]','PLLlgdvO0Nffb3KR4mVLu7j3shB2ViZLGP',1,art + '')
        addDir('[COLOR orange][B]MOST BEAUTIFUL LOVE SONGS[/B][/COLOR]','PLAN2ijY9WzlwYR6_WtieIZtqZ94Wke5o9',1,art + '')
        addDir('[COLOR dodgerblue][B]BEST SONGS EVER[/B][/COLOR]','PLjZf72-EsullE1D-3zZj1Q1AVQS-zBzj5',1,art + '')
        addDir('[COLOR red][B]GREATEST HITS OF THE 80[/B][/COLOR]','PLEffX5-5DhPtWTyU3r8nm-ha6DySzKzoW&index=2',1,art + '')
        addDir('[COLOR darkmagenta][B]GREATEST HITS OF THE 70s 80s[/B][/COLOR]','PL8ICnoVYi7pc7AftMD5aY98hSkv3K0BEB',1,art + '')
        addDir('[COLOR cyan][B]BEST MOTOWN SONGS OF ALL TIME[/B][/COLOR]','PLwXYgB2CtnVM4M_yqVtxYpnJB3I95HU-l',1,art + '')
        addDir('[COLOR darkgoldenrod][B]BEST OLDIES LOVE SONGS OF ALL TIME[/B][/COLOR]','PLwXYgB2CtnVOLnv_SCr4V6YMKYwj92fhk',1,art + '')
        addDir('[COLOR orangered][B]GREATEST SOUL SONGS[/B][/COLOR]','PL00ZqAjyF5PW5uT90RAcS4UrEijLucslj',1,art + '')
        addDir('[COLOR salmon][B]GREATEST 70S 80S ROCK SONGS[/B][/COLOR]','PLYUQMTiCwszIPKuHfAaA7pcaM0Y6ljT6g',1,art + '')
        addDir('[COLOR chartreuse][B]BEST ROMANTIC ENGLISH LOVE SONGS[/B][/COLOR]','PLFjbVJl7eR36JfQl-_KbWf32e9aUwrJhO',1,art + '')
        addDir('[COLOR darkturquoise][B]CLASSIC OF THE 1986[/B][/COLOR]','PLtmCPKUMm2qafI6JvTqhIXwOK-LdtwXDv',1,art + '')
        addDir('[COLOR fuchsia][B]BALLADS 70 80 90 MIX[/B][/COLOR]','PLcKqw5e0etEDWf-kpMeDUE-4ZliLUha9J',1,art + '')
        addDir('[COLOR goldenrod][B]SLOW ROCK MEDLEY SONGS[/B][/COLOR]','PLa-b2dUvu_lB15vHu4qROJBKzPzVTbml2',1,art + '')
        addDir('[COLOR lawngreen][B]CLASSIC COLLECTION[/B][/COLOR]','PLmE-U8SJLN0TXSlUFjbq0c03jdig1920P',1,art + '')
        addDir('[COLOR limegreen][B]ROMANTIC SONGS EVER[/B][/COLOR]','PLjZf72-EsullE1D-3zZj1Q1AVQS-zBzj5',1,art + '')
        addDir('[COLOR maroon][B]DISCO 70S 80S 90S[/B][/COLOR]','PLGKE0rBZEgcN1z4AdApz9TSK7jkvO3SOh',1,art + '')
        addDir('[COLOR blue]Ultimate Music Artist Collection[/COLOR]','url',22,art + 'PlayLists.png')

def musicplaylists():
        addDir('[COLOR limegreen][B]THE BEST ARTIST ALL TIMES[/B][/COLOR]','PLmE-U8SJLN0TXSlUFjbq0c03jdig1920P',1,art + 'master.png')
        addDir('[COLOR limegreen][B]CLASSIC SONGS ALL TIMES[/B][/COLOR]','PL3485902CC4FB6C67',1,art + 'master.png')		
        addDir('[COLOR limegreen][B]PHILL COLLINS[/B][/COLOR]','PL78645F08099E55F9',1,art + 'master.png')
        addDir('[COLOR limegreen][B]BRIAN ADAMS[/B][/COLOR]','PL54D3F57300A406FA',1,art + 'master.png')
        addDir('[COLOR limegreen][B]BON JOVI[/B][/COLOR]','PL574FBF341B72DAD5',1,art + 'master.png')
        addDir('[COLOR limegreen][B]GUNS AND ROSES[/B][/COLOR]','PLE6EB681577F21B3C',1,art + 'master.png')
        addDir('[COLOR limegreen][B]LED ZEPPELIN[/B][/COLOR]','PLjH4YJfu1WfE2bciiQZ7Ci0TiIDzYE3HJ',1,art + 'master.png')
        addDir('[COLOR limegreen][B]QUIET RIOT[/B][/COLOR]','PLPTh1c6pC1BxPCNypTxkzSpbWcOgpstC6',1,art + 'master.png')
        addDir('[COLOR limegreen][B]SCORPIONS[/B][/COLOR]','PL8AB0F5120809FF19',1,art + 'master.png')
        addDir('[COLOR limegreen][B]QUEENS[/B][/COLOR]','PLqDzNilwDj_dm_BOGxoCRmvA6CheRwAiw',1,art + 'master.png')
        addDir('[COLOR limegreen][B]TWISTED SISTER[/B][/COLOR]','PL29662FBF0FC8F98D',1,art + 'master.png')
        addDir('[COLOR limegreen][B]DEEP PURPLE[/B][/COLOR]','PL8384361C552AE037',1,art + 'master.png')
        addDir('[COLOR limegreen][B]AC DC[/B][/COLOR]','PLQlc99hV-nkGWDaG-gJxwOfqp8jxyHaaQ',1,art + 'master.png')
        addDir('[COLOR limegreen][B]KISS[/B][/COLOR]','PL71A9E09DEF0CE017',1,art + 'master.png')
        addDir('[COLOR limegreen][B]EUROPE[/B][/COLOR]','PLDD6E90D62FC64610',1,art + 'master.png')
        addDir('[COLOR limegreen][B]BARON ROJO[/B][/COLOR]','PL79E4245F0137AA18',1,art + 'master.png')
        addDir('[COLOR limegreen][B]BONNIE TYLER[/B][/COLOR]','PLvz78UNxtDruCicAvERgXFk2XVgiBn_4y',1,art + 'master.png')
        addDir('[COLOR limegreen][B]TOTO[/B][/COLOR]','PLyNIUJIA6jp58gmBKIUQ5zh4UWRxQtXKe',1,art + 'master.png')
        addDir('[COLOR limegreen][B]FOREIGNER[/B][/COLOR]','PL72D7EDFFBD267A94',1,art + 'master.png')
        addDir('[COLOR limegreen][B]KANSAS[/B][/COLOR]','PLCCAB3C8590D69DC1',1,art + 'master.png')
        addDir('[COLOR limegreen][B]BEE GEES[/B][/COLOR]','PLE572452B578F4B90',1,art + 'master.png')
        addDir('[COLOR limegreen][B]ROLLING STONE[/B][/COLOR]','PLP02sRgldWRb9LjuQgJ4AfxCd4cxygDrA',1,art + 'master.png')
        addDir('[COLOR limegreen][B]BEATLES[/B][/COLOR]','PLmo4pBukfRoN8SB5RKvfiY9CTl9pI_IFc',1,art + 'master.png')
        addDir('[COLOR limegreen][B]THE DOORS[/B][/COLOR]','PL7DlGI0vwP4S6tlQ-kMqrl6VCaN053_BN',1,art + 'master.png')
        addDir('[COLOR limegreen][B]JIMI HENDRIX[/B][/COLOR]','PLMKA5kzkfqk2GEImRCIqGqWmQvKYygUhG',1,art + 'master.png')
        addDir('[COLOR limegreen][B]VAN HALEN[/B][/COLOR]','PLoIh3u70c_PKEjlagdBAK3cEe_wXKSee2',1,art + 'master.png')		
        addDir('[COLOR limegreen][B]THE EAGLE[/B][/COLOR]','PLwNBAifp_VilC7ch4uI0SQgxkRch4qzPh',1,art + 'master.png')
        addDir('[COLOR limegreen][B]THE POLICE[/B][/COLOR]','PL36494E8634856791',1,art + 'master.png')
        addDir('[COLOR limegreen][B]U2[/B][/COLOR]','PL57CDBF4FB33C5BC1',1,art + 'master.png')
        addDir('[COLOR limegreen][B]NIRVANA[/B][/COLOR]','PLF1D793B61571DD4A',1,art + 'master.png')
        addDir('[COLOR limegreen][B]METALLICA[/B][/COLOR]','PL926CCB27995D3E94',1,art + 'master.png')
        addDir('[COLOR limegreen][B]THE WHO[/B][/COLOR]','PLB2359E68D19BA3C0',1,art + 'master.png')
        addDir('[COLOR limegreen][B]PINK FLOYD[/B][/COLOR]','PL8CQIFqDrjYUVdJbkHe4--PkWZYBB3NoW',1,art + 'master.png')
        addDir('[COLOR limegreen][B]AEROSMITH[/B][/COLOR]','PL9E80D3CB56F329AF',1,art + 'master.png')
        addDir('[COLOR limegreen][B]ALICE COOPER[/B][/COLOR]','PLzMhF_Kgqw3iZBdZ4sX-kdVaWPCEo3q9B',1,art + 'master.png')
        addDir('[COLOR limegreen][B]MEAT LOAF[/B][/COLOR]','PLslHapSMmen25gJiJ1h4ljKgGctdoRMbM',1,art + 'master.png')
        addDir('[COLOR limegreen][B]OZZY OSBOURNE[/B][/COLOR]','PLjsINEkV8yYEvi_6VtsI8BSqFXM1QtQwM',1,art + 'master.png')


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
page = None
token = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except:
	try: 
		mode=params["mode"]
	except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: token=urllib.unquote_plus(params["token"])
except: pass
try: page=int(params["page"])
except: page = 1

print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("iconimage: "+str(iconimage))
print ("Page: "+str(page))
print ("Token: "+str(token))

		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        return_youtubevideos(name,url,token,page)

elif mode==5: 
        play_youtube_video(url)

elif mode==6:
        mark_as_watched(url)

elif mode==7:
        removed_watched(url)

elif mode==8:
        add_to_bookmarks(url)

elif mode==9:
        remove_from_bookmarks(url)

elif mode==10:
        print ""+url
        DiamondCinema()

elif mode==11:
        print ""+url
        starfanfilms()

elif mode==12:
        print ""+url
        KingsOfHorror()

elif mode==13:
        print ""+url
        cirquedusoleil()

elif mode==14:
        print ""+url
        urbangonewild()

elif mode==15:
        print ""+url
        blameitonrio()

elif mode==16:
        print ""+url
        nowthatisamazing()

elif mode==17:
        print ""+url
        topinmusic()

elif mode==18:
        print ""+url
        bodypaint()

elif mode==19:
        print ""+url
        gossip()

elif mode==20:
        print ""+url
        amazingddolls()

elif mode==21:
        print ""+url
        rockcollection()

elif mode==22:
        print ""+url
        musicplaylists()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
