# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
from resources.lib.modules import client,cleantitle,source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['cooltvseries.com']
        self.base_link = 'https://cooltvseries.com'
        self.search_link = '/%s/season-%s/'


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = cleantitle.geturl(tvshowtitle)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            http = self.base_link + self.search_link % (url, season)
            season = '%02d' % int(season)
            episode = '%02d' % int(episode)
            r = client.request(http)
            match = re.compile('<a href="(.+?)-S' + season + 'E' + episode + '-(.+?)">').findall(r)
            for url1, url2 in match:
                url = '%s-S%sE%s-%s' % (url1, season, episode,url2)
                return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None:
                return sources
            r = client.request(url)
            try:
                match = re.compile('<li><a href="(.+?)" rel="nofollow">(.+?)<').findall(r)
                for url, check in match:
                    quality, info = source_utils.get_release_quality(check, check)
                    sources.append({ 'source': 'Direct', 'quality': quality, 'language': 'en', 'info': info, 'url': url, 'direct': True, 'debridonly': False }) 
            except:
                return
        except Exception:
            return
        return sources


    def resolve(self, url):
        return url

