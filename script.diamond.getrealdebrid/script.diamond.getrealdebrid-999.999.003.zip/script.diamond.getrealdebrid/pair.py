###################################################################################
#(_)                                                                              #
# |________________________________________________                               #
# |*  *  *  *  *  *  * |##########################|                               #
# | *  *  *  *  *  *  *|==========================|                               #
# |*  *  *  *  *  *  * |##########################|                               #
# | *  *  *  *  *  *  *|==========================|                               #
# |*  *  *  *  *  *  * |##########################|      If your going to copy    #
# | *  *  *  *  *  *  *|==========================|         this addon just       #
# |*  *  *  *  *  *  * |##########################|         give credit!!!!       #
# |--------------------|==========================|                               #
# |###############################################|                               #
# |===============================================|                               #
# |###############################################|                               #
# |===============================================|                               #
# |###############################################|                               #
# |-----------------------------------------------|                               #
# |                                                                               #
# |    Pairing Add-on                                                             #
# |    Copyright (C) 2017 FTG                                                     #
# |                                                                               #
# |    This program is free software: you can redistribute it and/or modify       #
# |    it under the terms of the GNU General Public License as published by       #
# |    the Free Software Foundation, either version 3 of the License, or          #
# |    (at your option) any later version.                                        #
# |                                                                               #
# |    This program is distributed in the hope that it will be useful,            #
# |    but WITHOUT ANY WARRANTY; without even the implied warranty of             #
# |    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              #
# |    GNU General Public License for more details.                               #
# |                                                                               #
###################################################################################

import urllib,urllib2,webbrowser,sys,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os

def menu():
	dialog = xbmcgui.Dialog()
	items = [
			('[COLOR yellow]Get Real Debrid[/COLOR] -- http://real-debrid.com/', 'realdebrid' ),
			]
	select = selectDialog([i[0] for i in items], 'Select Site To Pair with')
	if select == -1: return
	items =  items[select][1]
	site(items)
	return

def site(items):
	if items == 'realdebrid':
		site = 'http://real-debrid.com/?id=1811400'
		opensite(site)

def opensite(site):
	os = platform()
	if os == 'android':
		xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' % (site) )
	else:
		webbrowser.open(site)

def platform():
	if xbmc.getCondVisibility('system.platform.android'):
		return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):
		return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):
		return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):
		return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):
		return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):
		return 'ios'

def idle():
	return xbmc.executebuiltin('Dialog.Close(busydialog)')
addonInfo = xbmcaddon.Addon().getAddonInfo

def selectDialog(list, heading=addonInfo('name')):
	dialog = xbmcgui.Dialog()
	return dialog.select(heading, list)
menu()