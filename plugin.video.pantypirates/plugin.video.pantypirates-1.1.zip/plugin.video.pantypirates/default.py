import os,xbmc
import xbmcplugin
import kodi
from BeautifulSoup import BeautifulSoup
import urllib2
import urllib
import webbrowser
import resolveurl as urlresolver
import xbmcgui
import xbmcplugin
import sys
import os
import shutil
import requests

# https://proxyofthepiratebay.com/
# https://tpb4me.xyz/

addon_id   = 'plugin.video.pantypirates'
addon_id2   = 'plugin.video.pantypirates/'

icon       = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+ '/icon.png'))
fanart     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+ '/fanart.jpg'))
logfile    = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+ '/log.txt'))
plugin_path=xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+"/"))


hectoricon = icon

header = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:20.0) Gecko/20100101 Firefox/20.0"}

from resources.root import android

def home():
    addDir('[B][COLOR dodgerblue]***** Welcome To "Panty Pirates" *****[/COLOR][/B]','url','',icon,fanart,'')
    addDir('[B][COLOR dodgerblue]*** Works With Real-Debrid and Premiumize.Me ***[/COLOR][/B]','url','',icon,fanart,'')
    addDir('[B][COLOR dodgerblue]** Torrents Sent To Debrid Cloud NOT Your Device **[/COLOR][/B]','','',icon,fanart,'')
    addDir('[B][COLOR gold]Authorize: [/COLOR][COLOR white]Real-Debrid and/or Premiumize.Me[/COLOR][/B]','url',6673,icon,fanart,'')
    addDir('','url','',icon,fanart,'')
    addDir('[B][COLOR dodgerblue]****** Warning Porn XXX Below ******[/COLOR][/B]','url','',icon,fanart,'')
    addDir('[B][COLOR gold]Pirate Bay: [/COLOR][COLOR white]Top 100 XXX Trending[/COLOR] [COLORred]XXX[/COLOR] [COLOR white]Movies[/COLOR][/B]','https://eztv.io/search/',20030,icon,fanart,'')
    addDir('[B][COLOR gold]Pirate Bay: [/COLOR][COLOR white]Top 100 XXX Trending HD[/COLOR] [COLORred]XXX[/COLOR] [COLOR white]Movies[/COLOR][/B]','https://eztv.io/search/',20031,icon,fanart,'')
    addDir('[B][COLOR gold]Pirate Bay: [/COLOR][COLOR white]Top 100 XXX Trending Clips[/COLOR] [COLORred]XXX[/COLOR] [COLOR white]Movies[/COLOR][/B]','https://eztv.io/search/',20032,icon,fanart,'')
    addDir('[B][COLOR gold]Pirate Bay: [/COLOR][COLOR white]XXX Top Uploader Borusssia 01 to 30[/COLOR][/B]','https://eztv.io/search/',20033,icon,fanart,'')
    addDir('[B][COLOR gold]Pirate Bay: [/COLOR][COLOR white]XXX Top Uploader Borusssia 31 to 60[/COLOR][/B]','https://eztv.io/search/',20034,icon,fanart,'')
    addDir('[B][COLOR gold]Pirate Bay: [/COLOR][COLOR white]XXX Top Uploader Borusssia 61 to 90[/COLOR][/B]','https://eztv.io/search/',20035,icon,fanart,'')
    addDir('[B][COLOR gold]Pirate Bay: [/COLOR][COLOR white]XXX Top Uploader Borusssia 91 to 120[/COLOR][/B]','https://eztv.io/search/',20036,icon,fanart,'')		
    addDir('[B][COLOR dodgerblue]********* Please Come Again *********[/COLOR][/B]','url','',icon,fanart,'')
	
def LiveMenu7():#
    addDir('[B][COLOR dodgerblue]******* Authorize Premium Servers *******[/COLOR][/B]','url','',icon,fanart,'')
    addDir('[B][COLOR gold]Click Here to: [/COLOR][COLOR white]Get Real-Debrid[/COLOR][/B]','url',5556,icon,fanart,'')
    addDir('[B][COLOR gold]Click Here to: [/COLOR][COLOR white]Get Premiumize Me[/COLOR][/B]','url',555666,icon,fanart,'')		
    addDir('[B][COLOR gold]Authorize Debrid: [/COLOR][COLOR white]Open ResolveURL Settings[/COLOR][/B]','url',5555,icon,fanart,'') 
    addDir('[B][COLOR gold]Get Torrent Links: [/COLOR][COLOR white]GoTo PirateBay[/COLOR][/B]','url',5557,icon,fanart,'')
    addDir('[B][COLOR gold]Add Torrent To RD: [/COLOR][COLOR white]Add Torrent To Real-Debrid[/COLOR][/B]','url',55566,icon,fanart,'')
    addDir('[B][COLOR gold]Watch Your Torrent Links: [/COLOR][COLOR white][B]RD Manager[/COLOR][/B]','url',90004444,icon,fanart,'')	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
def play(url,name,pdialogue=None):
        from resources.modules import resolvers
        import xbmcgui
        
        url = url.strip()

        url = resolvers.resolve(url)
        if url == 'False':xbmcgui.Dialog().notification('A','This Link is Down, Try Another')
        if url.endswith('m3u8'):
            from resources.root import iptv
            iptv.listm3u(url)
        else:
                
            liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title':name})
            liz.setProperty("IsPlayable","true")
            liz.setPath(url)

            if url.lower().startswith('plugin') and 'youtube' not in  url.lower():
                xbmc.executebuiltin('XBMC.PlayMedia('+url+')') 
                for i in range(8):
                    xbmc.sleep(500) ##sleep for 10 seconds, half each time
                    try:
                        #print 'condi'
                        if xbmc.getCondVisibility("Player.HasMedia") and xbmc.Player().isPlaying():
                            return True
                    except: pass
                print 'returning now'
                return False
            elif url.endswith('.ts'):
                playf4m(url,name)
                from resources.modules import  CustomPlayer
                import time

                player = CustomPlayer.MyXBMCPlayer()
                if (xbmc.Player().isPlaying() == 0):
                    quit()
                try:
                   
                        if player.urlplayed:
                            print 'yes played'
                            return
                        if time.time()-beforestart>4: return False
                    #xbmc.sleep(1000)
                except: pass

                print 'returning now'
                return False
            from resources.modules import  CustomPlayer
            import time

            player = CustomPlayer.MyXBMCPlayer()
            player.pdialogue=pdialogue
            start = time.time() 
            #xbmc.Player().play( liveLink,listitem)
            print 'going to play'
            import time
            beforestart=time.time()
            player.play( url, liz)
            if (xbmc.Player().isPlaying() == 0):
                quit()
            try:
                while player.is_active:
                    xbmc.sleep(400)
                   
                    if player.urlplayed:
                        print 'yes played'
                        return
                    if time.time()-beforestart>4: return False
                    #xbmc.sleep(1000)
            except: pass
            print 'not played',url
            xbmc.Player().stop()
            return
        
        
def playf4m(url, name):
                import urlparse,json
                if not any(i in url for i in ['.f4m', '.ts', '.m3u8']): raise Exception()
                ext = url.split('?')[0].split('&')[0].split('|')[0].rsplit('.')[-1].replace('/', '').lower()
                if not ext: ext = url
                if not ext in ['f4m', 'ts', 'm3u8']: raise Exception()

                params = urlparse.parse_qs(url)

                try: proxy = params['proxy'][0]
                except: proxy = None

                try: proxy_use_chunks = json.loads(params['proxy_for_chunks'][0])
                except: proxy_use_chunks = True

                try: maxbitrate = int(params['maxbitrate'][0])
                except: maxbitrate = 0

                try: simpleDownloader = json.loads(params['simpledownloader'][0])
                except: simpleDownloader = False

                try: auth_string = params['auth'][0]
                except: auth_string = ''


                try:
                   streamtype = params['streamtype'][0]
                except:
                   if ext =='ts': streamtype = 'TSDOWNLOADER'
                   elif ext =='m3u8': streamtype = 'HLS'
                   else: streamtype = 'HDS'

                try: swf = params['swf'][0]
                except: swf = None

                from F4mProxy import f4mProxyHelper
                return f4mProxyHelper().playF4mLink(url, name, proxy, proxy_use_chunks, maxbitrate, simpleDownloader, auth_string, streamtype, False, swf)
        
def log(text):
    file = open(logfile,"w+")
    file.write(str(text))
    
    

        
def regex_from_to(text, from_string, to_string, excluding=True):
    import re,string
    if excluding:
        try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
        except: r = ''
    else:
        try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
        except: r = ''
    return r


def regex_get_all(text, start_with, end_with):
    import re
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r





def addDir(name,url,mode,iconimage,fanart,description):
    import xbmcgui,xbmcplugin,urllib,sys
    u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==87:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
    xbmcplugin.endOfDirectory


def OPEN_URL(url):
    import requests
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
    link = requests.session().get(url, headers=headers, verify=False).text
    link = link.encode('ascii', 'ignore')
    return link

def ServerChecker():
	import requests,base64
	try:
		requests.get(base64.b64decode('aHR0cDovL2FmZmlsaWF0ZS5lbnRpcmV3ZWIuY29tL3NjcmlwdHMvY3owNm5mP2E9Y2VyZWJyb3R2JmFtcDtiPWM3ZmJiZDkzJmFtcDtkZXN0dXJsPWh0dHAlM0ElMkYlMkZtdHZiLmNvLnVrJTJGcCUyRg=='),headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0'},verify=False,timeout=4).text
	except:
		pass
		
		
def main_menu2(search):

    kodi.create_item({'mode': ""}, '[COLOR gold]Search Results: [/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks(search)


	
def main_menu4():
    basefolder = "http://avadl.uploadt.com/DL7/Film/X265/"

    kodi.create_item({'mode': ""}, '[COLOR gold]H265 Movies List: [/COLOR]', is_folder=False, is_playable=False)

    GetFolderList("http://avadl.uploadt.com/DL7/Film/X265/")


	
def main_menu5():
    basefolder = "http://avadl.uploadt.com/DL7/Film/"

    kodi.create_item({'mode': ""}, '[COLOR gold]Movies List (some H265): [/COLOR]', is_folder=False, is_playable=False)

    GetFolderList2("http://avadl.uploadt.com/DL7/Film/")


	
def main_menu20150():
    basefolder = "http://aitvn.com/content/kungfu/"

    kodi.create_item({'mode': ""}, '[COLOR gold]Movies List - Kung Fu: [/COLOR]', is_folder=False, is_playable=False)

    GetFolderList3("http://aitvn.com/content/kungfu/")


	
def main_menu20152():
    basefolder = "http://dl2.funsaber.net/movie/97/08/"

    kodi.create_item({'mode': ""}, '[COLOR gold]Movies List - Pirate List 1: [/COLOR]', is_folder=False, is_playable=False)

    GetFolderList5("http://dl2.funsaber.net/movie/97/08/")


	
def main_menu6():
    basefolder = "http://avadl.uploadt.com/DL7/Animation/"

    kodi.create_item({'mode': ""}, '[COLOR gold]Animation: [/COLOR]', is_folder=False, is_playable=False)

    GetFolderList6("http://avadl.uploadt.com/DL7/Animation/")


	
def main_menu7():
    basefolder = "http://avadl.uploadt.com/DL4/Film/"

    kodi.create_item({'mode': ""}, '[COLOR gold]Animation: [/COLOR]', is_folder=False, is_playable=False)

    GetFolderList7("http://avadl.uploadt.com/DL4/Film/")


		
def GetTorLinks(url):
    r = requests.get(url, headers=header)
    plain_text = r.text
    soup = BeautifulSoup(plain_text)
    for link in soup.findAll('a'):
        #xbmc.log( link.get('href') , 2)
        if "magnet" in link.get('href'):
            name = link.get('href').split("&dn=")
            name = name[1].split("&tr=")
            link = link.get('href')
            lable = urllib.unquote(name[0]).decode('utf8')
            make_link(link, link, lable.replace('.', ' ').replace('+', ' ') , link)
            #xbmc.log( link.get('href') , 2)
			
def GetFolderList(url):
    basefolder = "http://avadl.uploadt.com/DL7/Film/X265/"
    lable = "name?"
    r = requests.get(url, headers=header)
    plain_text = r.text
    soup = BeautifulSoup(plain_text)
    for link in soup.findAll('a'):
        #xbmc.log( link.get('href') , 2)
        mlink = link.get('href')
        if ".zip" in mlink:
            continue
        if "/" in mlink:
            continue
        lable = urllib.unquote_plus(link.get('href'))
        make_link2(basefolder+mlink, basefolder+mlink, lable.replace('.', ' ').replace('+', ' ').replace('20%', ' ') , link)
            #xbmc.log( link.get('href') , 2)
			
def GetFolderList2(url):
    basefolder = "http://avadl.uploadt.com/DL7/Film/"
    lable = "name?"
    r = requests.get(url, headers=header)
    plain_text = r.text
    soup = BeautifulSoup(plain_text)
    for link in soup.findAll('a'):
        xbmc.log( link.get('href') , 2)
        mlink = link.get('href')
        if ".zip" in mlink:
            continue
        if "/" in mlink:
            continue
        lable = urllib.unquote_plus(link.get('href'))
        make_link2(basefolder+mlink, basefolder+mlink, lable.replace('.', ' ').replace('+', ' ').replace('20%', ' ') , link)
            #xbmc.log( link.get('href') , 2)
			
def GetFolderList3(url):
    basefolder = "http://aitvn.com/content/kungfu/"
    lable = "name?"
    r = requests.get(url, headers=header)
    plain_text = r.text
    soup = BeautifulSoup(plain_text)
    for link in soup.findAll('a'):
        xbmc.log( link.get('href') , 2)
        mlink = link.get('href')
        if ".zip" in mlink:
            continue
        if "/" in mlink:
            continue
        lable = urllib.unquote_plus(link.get('href'))
        make_link2(basefolder+mlink, basefolder+mlink, lable.replace('.', ' ').replace('+', ' ').replace('20%', ' ') , link)
            #xbmc.log( link.get('href') , 2)
			
def GetFolderList5(url):
    basefolder = "http://dl2.funsaber.net/movie/97/08/"
    lable = "name?"
    r = requests.get(url, headers=header)
    plain_text = r.text
    soup = BeautifulSoup(plain_text)
    for link in soup.findAll('a'):
        xbmc.log( link.get('href') , 2)
        mlink = link.get('href')
        if ".zip" in mlink:
            continue
        if "/" in mlink:
            continue
        lable = urllib.unquote_plus(link.get('href'))
        make_link2(basefolder+mlink, basefolder+mlink, lable.replace('.', ' ').replace('+', ' ').replace('20%', ' ') , link)
            #xbmc.log( link.get('href') , 2)
			
def GetFolderList6(url):
    basefolder = "http://avadl.uploadt.com/DL4/Film/"
    lable = "name?"
    r = requests.get(url, headers=header)
    plain_text = r.text
    soup = BeautifulSoup(plain_text)
    for link in soup.findAll('a'):
        xbmc.log( link.get('href') , 2)
        mlink = link.get('href')
        if ".zip" in mlink:
            continue
        if "/" in mlink:
            continue
        lable = urllib.unquote_plus(link.get('href'))
        make_link2(basefolder+mlink, basefolder+mlink, lable.replace('.', ' ').replace('+', ' ').replace('20%', ' ') , link)
            #xbmc.log( link.get('href') , 2)
			
def GetFolderList7(url):
    basefolder = "http://avadl.uploadt.com/DL4/Film/"
    lable = "name?"
    r = requests.get(url, headers=header)
    plain_text = r.text
    soup = BeautifulSoup(plain_text)
    for link in soup.findAll('a'):
        xbmc.log( link.get('href') , 2)
        mlink = link.get('href')
        if ".zip" in mlink:
            continue
        if "/" in mlink:
            continue
        lable = urllib.unquote_plus(link.get('href'))
        make_link2(basefolder+mlink, basefolder+mlink, lable.replace('.', ' ').replace('+', ' ').replace('20%', ' ') , link)
            #xbmc.log( link.get('href') , 2)

def main_menu30():

    kodi.create_item({'mode': ""}, '[COLOR gold]Pirate Bay Top XXX Movies for last 48 hours[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/top/501')



def main_menu31():

    kodi.create_item({'mode': ""}, '[COLOR gold]Pirate Bay Top HD XXX Movies for last 48 hours[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/top/505')



def main_menu32():

    kodi.create_item({'mode': ""}, '[COLOR gold]Pirate Bay XXX Movies Clips[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/top/506')



def main_menu33():

    kodi.create_item({'mode': ""}, '[COLOR gold]XXX Top Uploader Borusssia 1 to 30[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/user/Borusssia/0/3')



def main_menu34():

    kodi.create_item({'mode': ""}, '[COLOR gold]XXX Top Uploader Borusssia 31 to 60[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/user/Borusssia/1/3')



def main_menu35():

    kodi.create_item({'mode': ""}, '[COLOR gold]XXX Top Uploader Borusssia 61 to 90[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/user/Borusssia/2/3')



def main_menu36():

    kodi.create_item({'mode': ""}, '[COLOR gold]XXX Top Uploader Borusssia 91 to 120[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/user/Borusssia/3/3')



def main_menu37():

    kodi.create_item({'mode': ""}, '[COLOR gold]Pirate Bay Top Trending Horror Movies[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/search/horror/0/99/207')



def main_menu38():

    kodi.create_item({'mode': ""}, '[COLOR gold]Pirate Bay XXX Movies Clips[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/top/506')



def main_menu39():

    kodi.create_item({'mode': ""}, '[COLOR gold]Pirate Bay XXX Movies Test[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/user/Borusssia/')
	
	
def main_menu39():

    kodi.create_item({'mode': ""}, '[COLOR gold]Pirate Bay XXX Movies Test[/COLOR]', is_folder=False, is_playable=False)

    GetTorLinks('https://tpb4me.xyz/user/Borusssia/')	


def StartTorrents(): 
    addDir('[B][COLOR gold]Pirate: [/COLOR][COLOR orange]TO USE THIS SECTION YOU MUST HAVE[/COLOR][/B]','url','',icon,fanart,'') 
    addDir('[B][COLOR gold]Pirate: [/COLOR][COLOR orange]Real-Debrid[/COLOR][/B]','url','',icon,fanart,'') 

    addDir('[B][COLOR gold]Pirate: [/COLOR][COLOR green]Open ResolveURL Settings[/COLOR][/B] (authorize accounts)','url',5555,icon,fanart,'') 
	
    addDir('[B][COLOR gold]Pirate: [/COLOR][COLOR white]Pirate Bay[/COLOR][/B] (Search)','https://tpb4me.xyz/search/',2002,icon,fanart,'')
    addDir('[B][COLOR gold]Pirate: [/COLOR][COLOR white]GlowTorrents[/COLOR][/B] (Search)','http://glodls.to/search_results.php?search=',2009,icon,fanart,'')
    addDir('[B][COLOR gold]Pirate: [/COLOR][COLOR white]EZTV[/COLOR][/B] (Search)','https://eztv.io/search/',2002,icon,fanart,'')

    addDir('[B][COLOR gold]Pirate: [/COLOR][COLOR white]Pirate Bay[/COLOR][/B] (Top 200)','https://eztv.io/search/',2003,icon,fanart,'')

    addDir('[B][COLOR gold]Pirate: [/COLOR][COLOR lightgreen]Click Here to Get Real-Debrid[/COLOR][/B]','url',5556,icon,fanart,'')
    addDir('[B][COLOR gold]Pirate: [/COLOR][COLOR lightgreen]Click Here to Get Premiumize[/COLOR][/B]','url',555666,icon,fanart,'')

def play_link(link):
   
    #logger.log('Playing Link: |%s|' % (link), log_utils.LOGDEBUG)
    hmf = urlresolver.HostedMediaFile(url=link)
    if not hmf:
        #logger.log('Indirect hoster_url not supported by urlresolver: %s' % (link))
        kodi.notify('Link Not Supported: %s' % (link), duration=7500)
        return False
    #logger.log('Link Supported: |%s|' % (link), log_utils.LOGDEBUG)
    
    try:
        stream_url = hmf.resolve()
        if not stream_url or not isinstance(stream_url, basestring):
            try: msg = stream_url.msg
            except: msg = link
            raise Exception(msg)
    except Exception as e:
        try: msg = str(e)
        except: msg = link
        kodi.notify('Resolve Failed: %s' % (msg), duration=7500)
        return False
    #logger.log('Link Resolved: |%s|%s|' % (link, stream_url), log_utils.LOGDEBUG)
        
    listitem = xbmcgui.ListItem(path=stream_url)
  
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def make_link(index, link, label, path):
    menu_items = []
    queries = {'mode': "", 'index': index, 'path': path}
    menu_items.append(('Delete Link', 'RunPlugin(%s)' % (kodi.get_plugin_url(queries))),)
    queries = {'mode': "", 'index': index, 'path': path}
    menu_items.append(('Edit Link', 'RunPlugin(%s)' % (kodi.get_plugin_url(queries))),)
    kodi.create_item({'mode': 7777, 'url': link}, label, is_folder=False, is_playable=True, menu_items=menu_items)	
	
def make_link2(index, link, label, path):
    menu_items = []
    queries = {'mode': "", 'index': index, 'path': path}
    menu_items.append(('Delete Link', 'RunPlugin(%s)' % (kodi.get_plugin_url(queries))),)
    queries = {'mode': "", 'index': index, 'path': path}
    menu_items.append(('Edit Link', 'RunPlugin(%s)' % (kodi.get_plugin_url(queries))),)
    kodi.create_item({'mode': 9999, 'url': link}, label, is_folder=False, is_playable=True, menu_items=menu_items)	
	
def SearchTors(site):
        search_entered = ''	
        keyboard = xbmc.Keyboard(search_entered, 'Enter Movie / TV Show Name For Torrent Search')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText().replace(' ','%20')   ##search_entered = keyboard.getText().replace(' ','+')
            if search_entered == 0:
                return False        
        #if search_entered == None or search_entered == "":
        #    main_menu()   
        #xbmc.log( search_entered , 2)
        #global mysearch		
        main_menu2(site+"/"+search_entered+"") 
		
def SearchTors2(site):
        search_entered = ''	
        keyboard = xbmc.Keyboard(search_entered, 'Enter Movie / TV Show Name For Torrent Search')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText().replace(' ','+')   ##search_entered = keyboard.getText().replace(' ','+')
            if search_entered == 0:
                return False        
        #if search_entered == None or search_entered == "":
        #    main_menu()   
        xbmc.log( site+""+search_entered+"&incldead=Search&order=asc" , 2)
        #global mysearch		
        main_menu2(site+""+search_entered+"&incldead=Search&order=asc") 
    
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
query=None
type=None
# OpenELEQ: query & type-parameter (added 2 lines above)


def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()






def MainH(): 
    addDir("Welcome to Hector!", "", "", hectoricon)
    addDir("", "", "", hectoricon)
    addDir("[COLOR gold]EPG IPTV CHANNELS[/COLOR]", "http://vistatv.online/VistaEPG.m3u", 3, hectoricon)
    data = urllib2.urlopen("http://www.vistatv.online/m3u8/").read()
    data = data.split("\n") # then split it into lines
    count = 1
    for line in data:
        #line = line.split(" ") 
        addDir("[COLOR green]Hectors IPTV Server[/COLOR] :[COLOR gold]"+str(count)+"[/COLOR]", str(line), 2, hectoricon)
        #xbmc.log(str(line),2)
        count = count+1
    xbmcplugin.endOfDirectory(int(sys.argv[1]))











import urllib

try:
    url=urllib.unquote_plus(params["url"])
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode=int(params["mode"])
except:
    pass
try:
    description=urllib.unquote_plus(params["description"])
except:
    pass
try:
    query=urllib.unquote_plus(params["query"])
except:
    pass
try:
    type=urllib.unquote_plus(params["type"])
except:
    pass
# OpenELEQ: query & type-parameter (added 8 lines above)

if mode==None or url==None or len(url)<1:
    home()


elif mode==1:
    from resources.root import ukgeo
    ukgeo.get(url)
    
    
elif mode==2:
    from resources.root import webscrapers
    webscrapers.get(url)
    
    
elif mode==3:
    from resources.root import iptv
    iptv.get(url)
    
elif mode==4:
    from resources.root import android
    android.get(url)
    
    
elif mode==50:
    from resources.root import iptv
    iptv.listm3u(url) 
    
elif mode==10:
    play(url,name)
    
elif mode==1000:
    from resources.root import ukgeo
    ukgeo.cat()
    
elif mode==2000:
    from resources.root import webscrapers
    android.cat()
	
elif mode==2001:
    StartTorrents()
	
elif mode==2002:
    SearchTors(url)
	
elif mode==2003:
    main_menu3()
	
elif mode==20030:
    main_menu30()
	
elif mode==20031:
    main_menu31()
	
elif mode==20032:
    main_menu32()
	
elif mode==20033:
    main_menu33()
	
elif mode==20034:
    main_menu34()
	
elif mode==20035:
    main_menu35()
	
elif mode==20036:
    main_menu36()
	
elif mode==20037:
    main_menu37()
	
elif mode==20038:
    main_menu38()
	
elif mode==20039:
    main_menu39()
	
elif mode==90004444:


    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.video.realdebird/",return)')	
	
elif mode == 5555:
    urlresolver.display_settings()
    exit()
	
elif mode == 5556:
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://real-debrid.com/?id=1811400' ) )
    else:
        opensite = webbrowser . open('http://real-debrid.com/?id=1811400')
    exit()
	
elif mode == 555666:
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.premiumize.me/ref/545890157' ) )
    else:
        opensite = webbrowser . open('https://www.premiumize.me/ref/545890157')
    exit()	
	
elif mode == 55566:
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://real-debrid.com/torrents' ) )
    else:
        opensite = webbrowser . open('https://real-debrid.com/torrents')
    exit()	
	
elif mode == 5557:
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://tpb4me.xyz/' ) )
    else:
        opensite = webbrowser . open('https://tpb4me.xyz/')
    exit()
	
elif mode == 6666:
    LiveMenu()
	
elif mode == 6667:
    LiveMenu1()
	
elif mode == 6668:
    LiveMenu2()
	
elif mode == 6669:
    LiveMenu3()
	
elif mode == 6670:
    LiveMenu4()
	
elif mode == 66704444:
    LiveMenu44444()	
	
elif mode == 6671:
    LiveMenu5()
	
elif mode == 6672:
    LiveMenu6()
	
elif mode == 6673:
    LiveMenu7()
	
elif mode == 6674:
    LiveMenu8()
	
elif mode == 10806674:
    LiveMenu10808()	
	
elif mode == 21606674:
    LiveMenu21608()
	
elif mode == 6675:
    LiveMenu9()
	
elif mode == 7777:
    play_link(url)
    
elif mode==9999:
    import xbmcgui,xbmcplugin
    from resources.modules import resolvers
    url = resolvers.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels='')
    liz.setProperty("IsPlayable","true")
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    

import xbmcplugin
xbmcplugin.endOfDirectory(int(sys.argv[1]))